import watchTodolist from './watchTodolist';

const sagaHomePage = [watchTodolist];

export default sagaHomePage;
