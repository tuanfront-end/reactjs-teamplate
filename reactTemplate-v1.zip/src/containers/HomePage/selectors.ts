export const todolistSelector = (state: AppState) => state.todolist;
