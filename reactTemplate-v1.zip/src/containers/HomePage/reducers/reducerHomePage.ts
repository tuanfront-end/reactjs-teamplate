import { todolist } from './reducerTodolist';

const reducerHomePage = {
  todolist,
};

export default reducerHomePage;
