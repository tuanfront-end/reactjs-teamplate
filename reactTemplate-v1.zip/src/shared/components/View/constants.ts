const COLUMN_FORMAT = ['xs', 'sm', 'md', 'lg'] as const;

export default COLUMN_FORMAT;
