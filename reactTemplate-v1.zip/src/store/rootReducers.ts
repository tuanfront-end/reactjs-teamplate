import reducerHomePage from 'containers/HomePage/reducers/reducerHomePage';

const rootReducers = {
  ...reducerHomePage,
};

export default rootReducers;
