export interface TodolistItem {
  id: string;
  text: string;
}
