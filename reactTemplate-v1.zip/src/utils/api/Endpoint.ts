export type TodolistEndpoint = 'todolist';
