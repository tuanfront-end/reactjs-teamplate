export const pixabay = 'https://pixabay.com/api/?key=820016-aa5ce7345cd6e30f27339650e&image_type=all&pretty=true';
export const unsplash = 'https://api.unsplash.com/photos';
export const pexels = 'https://api.pexels.com/v1/search';
